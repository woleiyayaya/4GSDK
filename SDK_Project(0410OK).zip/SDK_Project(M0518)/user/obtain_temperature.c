#include "obtain_temperature.h"
#include "M0518.h"


#define K 10                                                                             //��ͨ�˲�ϵ��
#define TABLELEN  (sizeof(check_list)>>1)                                                //�¶ȶ��ձ�����

/**********   external variables   ********/
extern uint32_t adcConversionData;                                                       //ADC��ȡ��ֵ

/**********   local variables   **********/
static int16_t priviousData[2];                                                          //�¶Ⱦ�ֵ
static int16_t thisData[2];                                                              //�¶���ֵ

/**********   local functions prototype     **********/
void filtering(int16_t *old_val, int16_t *new_val, uint8_t len);                         //һ�׵�ͨ�˲�
uint16_t table_lookUp(int16_t NTC_data);                                                 //�������

 
/****************       �¶���ֵ���ձ�       ****************/
const uint16_t check_list[] = 
{
	  0xF88, 0xF85, 0xF7E, 0xF76, 0xF6F, 0xF66, 0xF5E, 0xF55, 0xF4C, 0xF42,  //-50�� --- -41��
    0xF38, 0xF2E, 0xF22, 0xF17, 0xF0B, 0xEFE, 0xEF1, 0xEE4, 0xED6, 0xEC7,  //-40�� --- -31��
    0xEB6, 0xEA6, 0xE95, 0xE83, 0xE71, 0xE5F, 0xE4B, 0xE38, 0xE23, 0xE0E,  //-30�� --- -21��
    0xDF8, 0xDE1, 0xDCA, 0xDB2, 0xD99, 0xD80, 0xD66, 0xD4C, 0xD30, 0xD14,  //-20�� --- -11��
    0xCF8, 0xCDA, 0xCBD, 0xC9E, 0xC7F, 0xC5F, 0xC3F, 0xC1E, 0xBFC, 0xBDA,  //-10�� --- -1��
    0xBB8,                                                                 // 0��
    0xB95, 0xB72, 0xB4E, 0xB29, 0xB05, 0xAE0, 0xABA, 0xA94, 0xA6E, 0xA48,  // 0�� ---  10��
    0xA22, 0x9FB, 0x9D4, 0x9AD, 0x986, 0x95F, 0x938, 0x910, 0x8E9, 0x8C2,  // 11�� --- 20��
    0x89B, 0x874, 0x84D, 0x827, 0x800, 0x7DA, 0x7B4, 0x78E, 0x768, 0x743,  // 21�� --- 30��
    0x71E, 0x6FA, 0x6D6, 0x6B2, 0x68E, 0x66B, 0x649, 0x627, 0x605, 0x5E4,  // 31�� --- 40��
    0x5C3, 0x5A3, 0x583, 0x564, 0x545, 0x527, 0x509, 0x4EC, 0x4CF, 0x4B3,  // 41�� --- 50��
    0x498, 0x47D, 0x462, 0x448, 0x42E, 0x415, 0x3FD, 0x3E5, 0x3CD, 0x3B6,  // 51�� --- 60��
    0x3A0, 0x38A, 0x374, 0x35F, 0x34B, 0x336, 0x323, 0x310, 0x2FD, 0x2EA,  // 61�� --- 70��
    0x2D9, 0x2C7, 0x2B6, 0x2A5, 0x295, 0x285, 0x276, 0x267, 0x258, 0x24A,  // 71�� --- 80��
    0x23C, 0x22E, 0x221, 0x214, 0x207, 0x1FB, 0x1EF, 0x1E3, 0x1D8, 0x1CC,  // 81�� --- 90��
    0x1C2, 0x1B7, 0x1AD, 0x1A3, 0x199, 0x18F, 0x186, 0x17D, 0x174, 0x16B,  // 91�� ---100��
    0x163, 0x15B, 0x153, 0x14B, 0x144, 0x13C, 0x135, 0x12E, 0x127, 0x121,  // 101�� ---110��
    0x11A, 0x114, 0x10E, 0x108, 0x102, 0xFC,  0xF6,  0xF1,  0xEC,  0xE7,   // 111�� ---120��
    0xE2,  0xDD,  0xD8,  0xD3,  0xCF,  0xCA,  0xC6,  0xC2,  0xBE,  0xBA,   // 121�� ---130��
    0xB6,  0xB2,  0xAE,  0xAB,  0xA7,  0xA4,  0xA0,  0x9D,  0x9A,  0x97,   // 131�� ---140��
    0x94,  0x91,  0x8E,  0x8B,  0x88,  0x85,  0x83,  0x80,  0x7E,  0x7B,   // 141�� ---150��
    0x79,  0x77,  0x74,  0x72,  0x70,  0x6E,  0x6C,  0x6A,  0x68,  0x66,   // 151�� ---160��
    0x64,  0x62,  0x60,  0x5E,  0x5D,  0x5B,  0x59,  0x58,  0x56,  0x54,   // 161�� ---170��
    0x53,  0x51,  0x50,  0x4F,  0x4D,  0x4C,  0x4B,  0x49,  0x48,  0x47,   // 171�� ---180��
    0x45,  0x44,  0x43,  0x42,  0x41,  0x40,  0x3F,  0x3E,  0x3D,  0x3C,   // 181�� ---190��
    0x3B,  0x3A,  0x39,  0x38,  0x37,  0x36,  0x35,  0x34,  0x34,  0x33,   // 191�� ---200��
    0x32 
};



/**
  * @brief  ����¶�ֵ
  * @note   ʹ�õ�ͨ�˲�+ƽ��ֵ�˲�
  * @param  adcת��ֵ
  * @retval �¶�ֵ * 10
  */
int get_temperature(unsigned int adcConversionData)
{      	
	uint8_t i;
	uint8_t N = 7;                                                                              
	uint16_t totalValue = 0;
	
  for(i = 0;i < N;i++)
  {
		ADC_START_CONV(ADC);                                                                        
		
		if (0 == i) 
		{
			priviousData[0] = adcConversionData;
			thisData[0] = adcConversionData;
		}
		else 
		{
			priviousData[0] = thisData[0];
			thisData[0] = adcConversionData;
		}
		filtering(priviousData, thisData, 1);                                                                //һ�׵�ͨ�˲�
		totalValue += thisData[0];                                                                           //��ȡ10�ε�ͨ�˲�ֵ
  }	
	
	return table_lookUp((totalValue/N));                                                                   //����õ��¶�ֵ 
}

///**
//  * @brief  ���¶Ȼ�ȡ�������򵥷�װ
//  * @note   ������λ�ȡ�¶�ʧ�ܵ�����
//  * @param  None
//  * @retval None
//  */
//void init_temperatureObtain(void)
//{
//	get_temperature();
//}

/**
  * @brief  һ�׵�ͨ�˲�
  * @note   None
  * @param  ��ֵ
	* @param  ��ֵ
	* @param  Ҫ�˲���ֵ�Ķ���
  * @retval None
  */
void filtering(int16_t *old_val, int16_t *new_val, uint8_t len)
{
	uint8_t i;
	
	for(i = 0;i < len;i++)
  {
		if (new_val[i] < old_val[i])
    {
			new_val[i] = old_val[i] - (((old_val[i] - new_val[i]) * K)>>7);
    }
		
		if (new_val[i] > old_val[i])
		{
			new_val[i] = old_val[i] + (((new_val[i] - old_val[i]) * K)>>7);
		}
  }
}


/**
  * @brief  ���ѹ���ձ���ӵõ��¶�ֵ
  * @note   None
	* @param  ntc̽ͷ�õ�������
  * @retval �¶�ֵ(��Ҫ����10�ŵõ���ȷ���¶�ֵ)
  */
uint16_t table_lookUp(int16_t NTC_data)
{
	uint8_t i;
	uint16_t result = 0;
	
	if (NTC_data > check_list[0])
  {
		UART_Write(UART5, (uint8_t *)"\r\nThe temperature exceeds the upper limit\r\n", 43);                            //�¶ȳ�������
		return 0;
  }
	
	if (NTC_data < check_list[TABLELEN - 1])
  {
		UART_Write(UART5, (uint8_t *)"\r\nThe temperature is lower than the lower limit\r\n", 48);                      //�¶ȵ�������
		return 0;
  }
	
	for(i = 0;i < TABLELEN - 1;i++)
  {
		if (NTC_data <= check_list[i] && NTC_data >= check_list[i + 1])
    {
			result = i * 10 + (check_list[i] - NTC_data) * 10/(check_list[i] - check_list[i + 1]);     
			break;
    }
  }
	
	return (result - 500);
}



