#include "upload_Parameters.h"
#include <stdio.h>
#include <string.h>
#include "connect_to_AliCloud.h"
#include "data_to_Stored.h"
#include "taskManagement.h"
#include "tool_funcs.h"
#include "userConfig.h"
#include "M0518.h"


/************ local variables ************/
unsigned char bootUp_step = 0;                                                                  //属性参数上传步骤位


/************   global variable   ************/
unsigned char user_ppModified = 0;                                                              //标定用户修改了属性参数
WHICH_PPMODIFIED whichPPModified = {0};                                                         //指明用户修改了哪个属性参数


/**
 * @description: 开机上传所有属性参数
 * @param {type} 
 * @return: 
 */
void boot_upload(void)
{
	if (0 == ccpm_status.sub_succeed || 1 == ccpm_status.bootUpload_succeed) return ;              //订阅不成功阻塞或此阶段已经完成会阻塞此函数
	if (1 == ccpm_status.waitting_receipt) return ;                                                //处于接收回执消息状态则阻塞此函数
	bootUp_step++;                                                                                 //上传步骤位自增,推动属性参数上传
	
	//开机温度 A1 float (-100 ~ 999)
	if (1 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A1':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (propertyParameters.boot_temp/10.0f));
	}
	
	//停机温度 A2 float (-100 ~ 999)
	else if (2 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A2':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (propertyParameters.shutDown_temp/10.0f));
	}
	
	//实时温度最高告警值 A3 float (-100 ~ 999)
	else if (3 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A3':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (propertyParameters.temp_upper_limit/10.0f));
  }
	
	//实时温度最低告警值 A4 float (-100 ~ 999)
	else if (4 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A4':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (float)(propertyParameters.temp_lower_limit/10.0f));
  }
	
	//高低温告警延时 A6 int (0 ~ 120)
	else if (5 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A6':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.alarm_delay);
  }
	
	//制冷实时温度 A7 text
	else if (6 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
    \"{'params':{'A7':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		realTime_data.realTime_temp.T1/10.0f, realTime_data.realTime_temp.T2/10.0f, realTime_data.realTime_temp.T3/10.0f, \
		realTime_data.realTime_temp.T4/10.0f, realTime_data.realTime_temp.T5/10.0f, realTime_data.realTime_temp.T6/10.0f, realTime_data.realTime_temp.T7/10.0f, \
		realTime_data.realTime_temp.T8/10.0f, realTime_data.realTime_temp.T9/10.0f, realTime_data.realTime_temp.T10/10.0f);
  }
	
	//制冷温度校正 A8 int (-10 ~ 10)
	else if (7 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A8':{'T1':%d,'T2':%d,'T3':%d,'T4':%d,'T5':%d,'T6':%d,'T7':%d,'T8':%d,'T9':%d,'T10':%d}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		propertyParameters.temp_correction.T1, propertyParameters.temp_correction.T2, propertyParameters.temp_correction.T3, \
		propertyParameters.temp_correction.T4, propertyParameters.temp_correction.T5, propertyParameters.temp_correction.T6, propertyParameters.temp_correction.T7, \
		propertyParameters.temp_correction.T8, propertyParameters.temp_correction.T9, propertyParameters.temp_correction.T10);
  }
	
	//实时湿度 B1 text
	else if (8 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'B1':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		realTime_data.realTime_humidity.T1/10.0f, realTime_data.realTime_humidity.T2/10.0f, realTime_data.realTime_humidity.T3/10.0f, \
		realTime_data.realTime_humidity.T4/10.0f, realTime_data.realTime_humidity.T5/10.0f, realTime_data.realTime_humidity.T6/10.0f, realTime_data.realTime_humidity.T7/10.0f, \
		realTime_data.realTime_humidity.T8/10.0f, realTime_data.realTime_humidity.T9/10.0f, realTime_data.realTime_humidity.T10/10.0f);
  }
	
	//实时湿度最高告警值 B2 int (0 ~ 99)
	else if (9 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'B2':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.humidity_upper_limit);
  }
	
	//实时湿度最低告警值 B3 int (0 ~ 99)
	else if (10 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'B3':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.humidity_lower_limit);
  }
	
	//湿度校正 B5 int (-10 ~ 20)
	else if (11 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'B5':{'T1':%d,'T2':%d,'T3':%d,'T4':%d,'T5':%d,'T6':%d,'T7':%d,'T8':%d,'T9':%d,'T10':%d}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		propertyParameters.humidity_correction.T1, propertyParameters.humidity_correction.T2, propertyParameters.humidity_correction.T3, \
		propertyParameters.humidity_correction.T4, propertyParameters.humidity_correction.T5, propertyParameters.humidity_correction.T6, propertyParameters.humidity_correction.T7, \
		propertyParameters.humidity_correction.T8, propertyParameters.humidity_correction.T9, propertyParameters.humidity_correction.T10);
  }
	
	//A相电压 C1 text
	else if (12 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'C1':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		realTime_data.APhaseVoltage.T1/10.0f, realTime_data.APhaseVoltage.T2/10.0f, realTime_data.APhaseVoltage.T3/10.0f, \
		realTime_data.APhaseVoltage.T4/10.0f, realTime_data.APhaseVoltage.T5/10.0f, realTime_data.APhaseVoltage.T6/10.0f, realTime_data.APhaseVoltage.T7/10.0f, \
		realTime_data.APhaseVoltage.T8/10.0f, realTime_data.APhaseVoltage.T9/10.0f, realTime_data.APhaseVoltage.T10/10.0f);
  }
	
	//B相电压 C2 text
	else if (13 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'C2':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		realTime_data.BPhaseVoltage.T1/10.0f, realTime_data.BPhaseVoltage.T2/10.0f, realTime_data.BPhaseVoltage.T3/10.0f, \
		realTime_data.BPhaseVoltage.T4/10.0f, realTime_data.BPhaseVoltage.T5/10.0f, realTime_data.BPhaseVoltage.T6/10.0f, realTime_data.BPhaseVoltage.T7/10.0f, \
		realTime_data.BPhaseVoltage.T8/10.0f, realTime_data.BPhaseVoltage.T9/10.0f, realTime_data.BPhaseVoltage.T10/10.0f);
  }
	
	//C相电压 C3 text
	else if (14 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'C3':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		realTime_data.CPhaseVoltage.T1/10.0f, realTime_data.CPhaseVoltage.T2/10.0f, realTime_data.CPhaseVoltage.T3/10.0f, \
		realTime_data.CPhaseVoltage.T4/10.0f, realTime_data.CPhaseVoltage.T5/10.0f, realTime_data.CPhaseVoltage.T6/10.0f, realTime_data.CPhaseVoltage.T7/10.0f, \
		realTime_data.CPhaseVoltage.T8/10.0f, realTime_data.CPhaseVoltage.T9/10.0f, realTime_data.CPhaseVoltage.T10/10.0f);
  }
	
	//A相电流 C4 text
	else if (15 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'C4':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		realTime_data.APhaseCurrent.T1/10.0f, realTime_data.APhaseCurrent.T2/10.0f, realTime_data.APhaseCurrent.T3/10.0f, \
		realTime_data.APhaseCurrent.T4/10.0f, realTime_data.APhaseCurrent.T5/10.0f, realTime_data.APhaseCurrent.T6/10.0f, realTime_data.APhaseCurrent.T7/10.0f, \
		realTime_data.APhaseCurrent.T8/10.0f, realTime_data.APhaseCurrent.T9/10.0f, realTime_data.APhaseCurrent.T10/10.0f);
  }
	
	//B相电流 C5 text
	else if (16 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'C5':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		realTime_data.BPhaseCurrent.T1/10.0f, realTime_data.BPhaseCurrent.T2/10.0f, realTime_data.BPhaseCurrent.T3/10.0f, \
		realTime_data.BPhaseCurrent.T4/10.0f, realTime_data.BPhaseCurrent.T5/10.0f, realTime_data.BPhaseCurrent.T6/10.0f, realTime_data.BPhaseCurrent.T7/10.0f, \
		realTime_data.BPhaseCurrent.T8/10.0f, realTime_data.BPhaseCurrent.T9/10.0f, realTime_data.BPhaseCurrent.T10/10.0f);
  }
	
	//C相电流 C6 text
	else if (17 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'C6':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		realTime_data.CPhaseCurrent.T1/10.0f, realTime_data.CPhaseCurrent.T2/10.0f, realTime_data.CPhaseCurrent.T3/10.0f, \
		realTime_data.CPhaseCurrent.T4/10.0f, realTime_data.CPhaseCurrent.T5/10.0f, realTime_data.CPhaseCurrent.T6/10.0f, realTime_data.CPhaseCurrent.T7/10.0f, \
		realTime_data.CPhaseCurrent.T8/10.0f, realTime_data.CPhaseCurrent.T9/10.0f, realTime_data.CPhaseCurrent.T10/10.0f);
  }
	
	//位置(目前是虚的) D1
	else if (18 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'D1':{'lng':%.6f, 'lat':%.6f}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, 1.111111, 1.111111);
  }
	
	//压缩机停机保护时间 E1 int (0 ~ 120)
	else if (19 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'E1':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.shutDown_protection/10);
  }
	
	//灯状态 F1 enum (0:关 1:开)
	else if (20 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'F1':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.lamp_status);
  }
	
	//开关机状态 F2 enum (0:关 1:开)
	else if (21 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'F2':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.power_status);
  }
	
	//化霜周期 G2 int (0 ~ 24)
	else if (22 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G2':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.defrosting_cycle);
  }
	
	//化霜结束温度 G3 float (-100 ~ 999)
	else if (23 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G3':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (propertyParameters.defrosting_end_temp/10.0f));
	}
	
	//化霜持续时间 G4 int (0 ~ 999)
	else if (24 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G4':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.defrosting_duration);
  }
	
	//化霜滴水时间 G5 int (0 ~ 999)
	else if (25 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G5':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.defrosting_drip_time);
  }
	
	
	//化霜方式 G6 enum (0:电化霜 1:热氟化霜 2:停机化霜)
	else if (26 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G6':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.defrosting_mode);	
  }
	
	//化霜探头温度 G7 text
	else if (27 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
    \"{'params':{'G7':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		realTime_data.realTime_defrostTemp.T1/10.0f, realTime_data.realTime_defrostTemp.T2/10.0f, realTime_data.realTime_defrostTemp.T3/10.0f, \
		realTime_data.realTime_defrostTemp.T4/10.0f, realTime_data.realTime_defrostTemp.T5/10.0f, realTime_data.realTime_defrostTemp.T6/10.0f, realTime_data.realTime_defrostTemp.T7/10.0f, \
		realTime_data.realTime_defrostTemp.T8/10.0f, realTime_data.realTime_defrostTemp.T9/10.0f, realTime_data.realTime_defrostTemp.T10/10.0f);
  }
	
	//化霜温度校正 G8 int (-10 ~ 10)
	else if (28 == bootUp_step)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G8':{'T1':%d,'T2':%d,'T3':%d,'T4':%d,'T5':%d,'T6':%d,'T7':%d,'T8':%d,'T9':%d,'T10':%d}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		propertyParameters.defrosting_temp_correction.T1, propertyParameters.defrosting_temp_correction.T2, propertyParameters.defrosting_temp_correction.T3, \
		propertyParameters.defrosting_temp_correction.T4, propertyParameters.defrosting_temp_correction.T5, propertyParameters.defrosting_temp_correction.T6, propertyParameters.defrosting_temp_correction.T7, \
		propertyParameters.defrosting_temp_correction.T8, propertyParameters.defrosting_temp_correction.T9, propertyParameters.defrosting_temp_correction.T10);
	}
	
	//开机上传告警信息
	else if (29 == bootUp_step)
	{
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/alarm/post\",0,0,\"{'params':{'A5':0, 'B4':0, 'G9':0, 'C7':0, 'C8':0},'method':'thing.event.alarm.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName);
		//**********************************************
	  //至此，上传所有属性参数成功(包括告警信息)
		ccpm_status.bootUpload_succeed = 1;                                                             //上传属性参数成功
	}
	
	ccpm_status.waitting_receipt = 1;                                                                 //进入等待回执消息状态
}


/**
 * @description: 上传实时数据(实时制冷温度+实时湿度+化霜探头温度)(此函数的调用周期为100s)(与下一个函数相关联)
 * @param {void} 
 * @return: 
 */
void upload_realTimeData_1(void)
{
	if(0 == ccpm_status.bootUpload_succeed) return ;                          //未上传所有属性参数会阻塞此函数                  
	
	printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
	\"{'params':{'A7':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}, \
	             'B1':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}, \
	             'G7':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}},\
	'method':'thing.event.property.post'}\"\r\n", \
	dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
	realTime_data.realTime_temp.T1/10.0f, realTime_data.realTime_temp.T2/10.0f, realTime_data.realTime_temp.T3/10.0f, \
	realTime_data.realTime_temp.T4/10.0f, realTime_data.realTime_temp.T5/10.0f, realTime_data.realTime_temp.T6/10.0f, realTime_data.realTime_temp.T7/10.0f, \
	realTime_data.realTime_temp.T8/10.0f, realTime_data.realTime_temp.T9/10.0f, realTime_data.realTime_temp.T10/10.0f, \
	realTime_data.realTime_humidity.T1/10.0f, realTime_data.realTime_humidity.T2/10.0f, realTime_data.realTime_humidity.T3/10.0f, \
	realTime_data.realTime_humidity.T4/10.0f, realTime_data.realTime_humidity.T5/10.0f, realTime_data.realTime_humidity.T6/10.0f, realTime_data.realTime_humidity.T7/10.0f, \
	realTime_data.realTime_humidity.T8/10.0f, realTime_data.realTime_humidity.T9/10.0f, realTime_data.realTime_humidity.T10/10.0f, \
	realTime_data.realTime_defrostTemp.T1/10.0f, realTime_data.realTime_defrostTemp.T2/10.0f, realTime_data.realTime_defrostTemp.T3/10.0f, \
	realTime_data.realTime_defrostTemp.T4/10.0f, realTime_data.realTime_defrostTemp.T5/10.0f, realTime_data.realTime_defrostTemp.T6/10.0f, realTime_data.realTime_defrostTemp.T7/10.0f, \
	realTime_data.realTime_defrostTemp.T8/10.0f, realTime_data.realTime_defrostTemp.T9/10.0f, realTime_data.realTime_defrostTemp.T10/10.0f);
	
	ccpm_status.wr_timeout++;                                   //等待回执超时标志位自增
	ccpm_status.waitting_receipt = 1;                           //等待回执消息
	taskComponent[4].suspend = 0;                               //使upload_realTimeData_2()进入运行态, 准备上传电压和电流的实时数据
}


/**
 * @description: 上传实时数据(电压)(与下一个函数相关联)
 * @param {void} 
 * @return: 
 */
void upload_realTimeData_2(void)
{
	if(0 == ccpm_status.bootUpload_succeed) return ;            //未上传所有属性参数会阻塞此函数                  
	
	printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
	\"{'params':{'C1':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}, \
	             'C2':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}, \
	             'C3':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}},\
	'method':'thing.event.property.post'}\"\r\n", \
	dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
	realTime_data.APhaseVoltage.T1/10.0f, realTime_data.APhaseVoltage.T2/10.0f, realTime_data.APhaseVoltage.T3/10.0f, \
	realTime_data.APhaseVoltage.T4/10.0f, realTime_data.APhaseVoltage.T5/10.0f, realTime_data.APhaseVoltage.T6/10.0f, realTime_data.APhaseVoltage.T7/10.0f, \
	realTime_data.APhaseVoltage.T8/10.0f, realTime_data.APhaseVoltage.T9/10.0f, realTime_data.APhaseVoltage.T10/10.0f, \
	realTime_data.BPhaseVoltage.T1/10.0f, realTime_data.BPhaseVoltage.T2/10.0f, realTime_data.BPhaseVoltage.T3/10.0f, \
	realTime_data.BPhaseVoltage.T4/10.0f, realTime_data.BPhaseVoltage.T5/10.0f, realTime_data.BPhaseVoltage.T6/10.0f, realTime_data.BPhaseVoltage.T7/10.0f, \
	realTime_data.BPhaseVoltage.T8/10.0f, realTime_data.BPhaseVoltage.T9/10.0f, realTime_data.BPhaseVoltage.T10/10.0f, \
	realTime_data.CPhaseVoltage.T1/10.0f, realTime_data.CPhaseVoltage.T2/10.0f, realTime_data.CPhaseVoltage.T3/10.0f, \
	realTime_data.CPhaseVoltage.T4/10.0f, realTime_data.CPhaseVoltage.T5/10.0f, realTime_data.CPhaseVoltage.T6/10.0f, realTime_data.CPhaseVoltage.T7/10.0f, \
	realTime_data.CPhaseVoltage.T8/10.0f, realTime_data.CPhaseVoltage.T9/10.0f, realTime_data.CPhaseVoltage.T10/10.0f);
	
	ccpm_status.wr_timeout++;                                 //等待回执超时标志位自增
	ccpm_status.waitting_receipt = 1;                         //等待回执消息
	taskComponent[4].suspend = 1;                             //电压实时数据上传完成, 使upload_realTimeData_2()进入挂起态    
  taskComponent[5].suspend = 0;                             //使upload_realTimeData_3()进入运行态, 准备上传电流的实时数据	
}


/**
 * @description: 上传实时数据(电流)(与上一个函数相关联)
 * @param {void} 
 * @return: 
 */
void upload_realTimeData_3(void)
{
	if(0 == ccpm_status.bootUpload_succeed) return ;          //未上传所有属性参数会阻塞此函数                  
	
	printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
	\"{'params':{'C4':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}, \
	             'C5':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}, \
	             'C6':{'T1':'%.1f','T2':'%.1f','T3':'%.1f','T4':'%.1f','T5':'%.1f','T6':'%.1f','T7':'%.1f','T8':'%.1f','T9':'%.1f','T10':'%.1f'}},\
	'method':'thing.event.property.post'}\"\r\n", \
	dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
	realTime_data.APhaseCurrent.T1/10.0f, realTime_data.APhaseCurrent.T2/10.0f, realTime_data.APhaseCurrent.T3/10.0f, \
	realTime_data.APhaseCurrent.T4/10.0f, realTime_data.APhaseCurrent.T5/10.0f, realTime_data.APhaseCurrent.T6/10.0f, realTime_data.APhaseCurrent.T7/10.0f, \
	realTime_data.APhaseCurrent.T8/10.0f, realTime_data.APhaseCurrent.T9/10.0f, realTime_data.APhaseCurrent.T10/10.0f, \
	realTime_data.BPhaseCurrent.T1/10.0f, realTime_data.BPhaseCurrent.T2/10.0f, realTime_data.BPhaseCurrent.T3/10.0f, \
	realTime_data.BPhaseCurrent.T4/10.0f, realTime_data.BPhaseCurrent.T5/10.0f, realTime_data.BPhaseCurrent.T6/10.0f, realTime_data.BPhaseCurrent.T7/10.0f, \
	realTime_data.BPhaseCurrent.T8/10.0f, realTime_data.BPhaseCurrent.T9/10.0f, realTime_data.BPhaseCurrent.T10/10.0f, \
	realTime_data.CPhaseCurrent.T1/10.0f, realTime_data.CPhaseCurrent.T2/10.0f, realTime_data.CPhaseCurrent.T3/10.0f, \
	realTime_data.CPhaseCurrent.T4/10.0f, realTime_data.CPhaseCurrent.T5/10.0f, realTime_data.CPhaseCurrent.T6/10.0f, realTime_data.CPhaseCurrent.T7/10.0f, \
	realTime_data.CPhaseCurrent.T8/10.0f, realTime_data.CPhaseCurrent.T9/10.0f, realTime_data.CPhaseCurrent.T10/10.0f);
	
	ccpm_status.wr_timeout++;                                 //等待回执超时标志位自增
	ccpm_status.waitting_receipt = 1;                         //等待回执消息
	taskComponent[5].suspend = 1;                             //电压和电流的实时数据上传完成, 使upload_realTimeData_3()进入挂起态                      
}


/**
 * @description: 查询信号强度
 * @param {none} 
 * @return: 
 */
void query_signalStrength(void)
{
	if (!ccpm_status.cc_succeed || ccpm_status.waitting_receipt) return ;           //连云不成功或者处于等待回执消息的状态则阻塞此函数
	printf("AT+CSQ\r\n");
}


/**
 * @description: 及时上传修改了的属性参数
 * @param {void} 
 * @return: 
 */
void upload_modifiedPP(void)
{
	if(0 == ccpm_status.bootUpload_succeed) return ;          //未上传所有属性参数会阻塞此函数
	if (0 == user_ppModified) return ;                        //属性参数未被用户修改, 退出此函数
	
	if (whichPPModified.A1)          //开机温度 A1
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A1':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (propertyParameters.boot_temp/10.0f));
		
		whichPPModified.A1 = 0;
  }
	
	if (whichPPModified.A2)          //停机温度 A2
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A2':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (propertyParameters.shutDown_temp/10.0f));
		
		whichPPModified.A2 = 0;
  }
	
	if (whichPPModified.A3)          //实时温度最高告警值 A3
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A3':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (propertyParameters.temp_upper_limit/10.0f));
		
		whichPPModified.A3 = 0;
  }
	
	if (whichPPModified.A4)          //实时温度最低告警值 A4
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A4':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (float)(propertyParameters.temp_lower_limit/10.0f));
		
		whichPPModified.A4 = 0;
  }
	
	if (whichPPModified.A6)          //高低温告警延时 A6
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A6':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.alarm_delay);
		
		whichPPModified.A6 = 0;
  }
	
	if (whichPPModified.A8)
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A8':{'T1':%d,'T2':%d,'T3':%d,'T4':%d,'T5':%d,'T6':%d,'T7':%d,'T8':%d,'T9':%d,'T10':%d}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		propertyParameters.temp_correction.T1, propertyParameters.temp_correction.T2, propertyParameters.temp_correction.T3, \
		propertyParameters.temp_correction.T4, propertyParameters.temp_correction.T5, propertyParameters.temp_correction.T6, propertyParameters.temp_correction.T7, \
		propertyParameters.temp_correction.T8, propertyParameters.temp_correction.T9, propertyParameters.temp_correction.T10);
		
		whichPPModified.A8 = 0;
  }
	
	if (whichPPModified.B2)          //实时湿度最高告警值 B2
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'B2':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.humidity_upper_limit);
		
		whichPPModified.B2 = 0;
  }
	
	if (whichPPModified.B3)          //实时湿度最低告警值 B3
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'B3':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.humidity_lower_limit);
		
		whichPPModified.B3 = 0;
  }
	
	if (whichPPModified.B5)          //湿度校正 B5
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'B5':{'T1':%d,'T2':%d,'T3':%d,'T4':%d,'T5':%d,'T6':%d,'T7':%d,'T8':%d,'T9':%d,'T10':%d}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		propertyParameters.humidity_correction.T1, propertyParameters.humidity_correction.T2, propertyParameters.humidity_correction.T3, \
		propertyParameters.humidity_correction.T4, propertyParameters.humidity_correction.T5, propertyParameters.humidity_correction.T6, propertyParameters.humidity_correction.T7, \
		propertyParameters.humidity_correction.T8, propertyParameters.humidity_correction.T9, propertyParameters.humidity_correction.T10);
		
		whichPPModified.B5 = 0;
  }
	
	if (whichPPModified.E1)          //压缩机停机保护时间 E1
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'E1':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.shutDown_protection/10);
		
		whichPPModified.E1 = 0;
  }
	
	if (whichPPModified.F1)          //灯状态 F1
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'F1':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.lamp_status);
		
		whichPPModified.F1 = 0;
  }
	
	if (whichPPModified.F2)          //开关机状态 F2
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'F2':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.power_status);
		
		whichPPModified.F2 = 0;
  }
	
	if (whichPPModified.G2)          //化霜周期 G2
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G2':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.defrosting_cycle);
		
		whichPPModified.G2 = 0;
  }
	
	if (whichPPModified.G3)          //化霜结束温度 G3
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G3':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (propertyParameters.defrosting_end_temp/10.0f));
		
		whichPPModified.G3 = 0;
  }
	
	if (whichPPModified.G4)          //化霜持续时间 G4
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G4':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.defrosting_duration);
		
		whichPPModified.G4 = 0;
  }
	
	if (whichPPModified.G5)          //化霜滴水时间 G5
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G5':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.defrosting_drip_time);
		
		whichPPModified.G5 = 0;
  }
	
	if (whichPPModified.G6)          //化霜模式 G8
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G6':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.defrosting_mode);
		
		whichPPModified.G6 = 0;
  }
	
	if (whichPPModified.G8)          //化霜温度校正 G8
  {
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G8':{'T1':%d,'T2':%d,'T3':%d,'T4':%d,'T5':%d,'T6':%d,'T7':%d,'T8':%d,'T9':%d,'T10':%d}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		propertyParameters.defrosting_temp_correction.T1, propertyParameters.defrosting_temp_correction.T2, propertyParameters.defrosting_temp_correction.T3, \
		propertyParameters.defrosting_temp_correction.T4, propertyParameters.defrosting_temp_correction.T5, propertyParameters.defrosting_temp_correction.T6, propertyParameters.defrosting_temp_correction.T7, \
		propertyParameters.defrosting_temp_correction.T8, propertyParameters.defrosting_temp_correction.T9, propertyParameters.defrosting_temp_correction.T10);
    
		whichPPModified.G8 = 0;
	}
	
	user_ppModified = 0;                                               //用户修改属性参数标志位清零              
  ccpm_status.waitting_receipt = 1;                                  //等待消息回执
}

