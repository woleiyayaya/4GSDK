#include "data_to_Stored.h"
#include "M0518.h"
#include <stdio.h>
#include <string.h>

/************   global variable   ************/
Quadruple dev_quadruple = {0, 0, "", "", "", ""};                //设备四元组
SYS_Property propertyParameters = {0};                           //系统属性参数


/************ local function prototype ************/
void PP_factory_setting(SYS_Property *propertyParameters);       //属性参数结构体恢复出厂设置
void Q_factory_setting(Quadruple *dev_quadruple);                //四元组内容恢复出厂设置


/**
  * @brief  读取flash中的内容
  * @note   None
  * @param  读取的基地址
	* @param  存储读取数据的数组
	* @param  读取的数据长度
  * @retval None
  */
void flash_Read32(unsigned int addr, int *dest, unsigned char num)
{
	unsigned int i;
	
	SYS_UnlockReg();                        //解锁写保护寄存器
	FMC_ENABLE_ISP();                       //Enable FMC ISP function(同FMC_Open())
	for(i = 0;i < num;i++)                  //内容读取
  {
		*dest++ = FMC_Read(addr + i * 4);
  }
	FMC_DISABLE_ISP();                      //同(FMC_Close())
	SYS_LockReg();                          //启用写保护寄存器
}


/**
  * @brief  向flash中存入内容
  * @note   None
  * @param  None
  * @retval None
  */
void flash_Write32(unsigned int addr, int *sour, unsigned char num)
{
	unsigned char i;
	
	SYS_UnlockReg();                        //解锁写保护寄存器
	FMC_ENABLE_ISP();                       //Enable FMC ISP function(同FMC_Open())
	FMC_Erase(addr);                        //擦除以addr为起始地址的512字节内容
	
	for(i = 0;i < num;i++)                  //内容写入
  {
		FMC_Write(addr + i * 4, *sour++);
  }
	FMC_DISABLE_ISP();                      //同(FMC_Close())
	SYS_LockReg();                          //启用写保护寄存器
}


/**
  * @brief  初始化dataflash
  * @note   None
  * @param  void
  * @retval 0
  */
int dataFlash_init(void)
{
		//读取page0的数据到属性参数结构体变量
		flash_Read32(DATAFLASH_PAGE0, (int *)&propertyParameters, sizeof(SYS_Property)/4);
		if (0x66 != propertyParameters.checkout_1 && 0x66 != propertyParameters.checkout_2)           //校验位错误
    {
			UART_Write(UART3, (uint8_t *)"factory setting\r\n", 17);
			PP_factory_setting(&propertyParameters);                                                    //恢复出厂设置
			flash_Write32(DATAFLASH_PAGE0, (int *)&propertyParameters, sizeof(SYS_Property)/4);
    }
		
		//读取page1的数据到四元组结构体变量
		flash_Read32(DATAFLASH_PAGE1, (int *)&dev_quadruple, sizeof(Quadruple)/4);
		if (0x66 != dev_quadruple.checkout)
    {
			Q_factory_setting(&dev_quadruple);
			flash_Write32(DATAFLASH_PAGE1, (int *)&dev_quadruple, sizeof(Quadruple)/4);
    }
		
		return 0;
}


/**
  * @brief  属性参数恢复出厂设置
  * @note   None
  * @param  需要写入出厂数据的属性参数结构体变量
  * @retval None
  */
void PP_factory_setting(SYS_Property *propertyParameters)
{
	//校验位  用于检验是否是第一次开机
	propertyParameters->checkout_1 = 0X66;
	propertyParameters->checkout_2 = 0X66;
	
	//开机温度            A1 float (-100 ~ 999)
	//停机温度            A2 float (-100 ~ 999)
	//实时温度最高告警值  A3 float (-100 ~ 999)
	//实时温度最低告警值  A4 float (-100 ~ 999)
	//高低温告警延时      A6 int   (0 ~ 120)
	//制冷温度校正        A8 int   (-10 ~ 10)
	propertyParameters->boot_temp = 390;  
	propertyParameters->shutDown_temp = -50;
	propertyParameters->temp_upper_limit = 690;
	propertyParameters->temp_lower_limit = -690;
	propertyParameters->alarm_delay = 10;
	propertyParameters->temp_correction.T1 = 0;
	propertyParameters->temp_correction.T2 = 0;
	propertyParameters->temp_correction.T3 = 0;
	propertyParameters->temp_correction.T4 = 0;
	propertyParameters->temp_correction.T5 = 0;
	propertyParameters->temp_correction.T6 = 0;
	propertyParameters->temp_correction.T7 = 0;
	propertyParameters->temp_correction.T8 = 0;
	propertyParameters->temp_correction.T9 = 0;
	propertyParameters->temp_correction.T10 = 0;
	
	//实时湿度最高告警值 B2 int (0 ~ 99)
	//实时湿度最低告警值 B3 int (0 ~ 99)
	//湿度校正           B5 int (-10 ~ 20)
	propertyParameters->humidity_upper_limit = 50;
	propertyParameters->humidity_lower_limit = 0;
	propertyParameters->humidity_correction.T1 = 0;
	propertyParameters->humidity_correction.T2 = 0;
	propertyParameters->humidity_correction.T3 = 0;
	propertyParameters->humidity_correction.T4 = 0;
	propertyParameters->humidity_correction.T5 = 0;
	propertyParameters->humidity_correction.T6 = 0;
	propertyParameters->humidity_correction.T7 = 0;
	propertyParameters->humidity_correction.T8 = 0;
	propertyParameters->humidity_correction.T9 = 0;
	propertyParameters->humidity_correction.T10 = 0;

	
	//压缩机停机保护时间 E1 int (0 ~ 120)分钟
	propertyParameters->shutDown_protection = 3;
	
	//灯状态             F1 enum (0:关 1:开)
	//开关机状态         F2 enum (0:关 1:开)
	propertyParameters->lamp_status = 0;
	propertyParameters->power_status = 0;
	
	//化霜周期           G2 int   (0 ~ 24)小时
	//化霜结束温度       G3 float (-100 ~ 999)
	//化霜持续时间       G4 int   (0 ~ 999)
	//化霜滴水时间       G5 int   (0 ~ 999)
	//化霜方式           G6 enum  (0:电化霜 1:热氟化霜 2:停机化霜)
	//化霜温度探头校正   G8 int   (-10 ~ 10)
	propertyParameters->defrosting_cycle = 2;
	propertyParameters->defrosting_end_temp = 100;
	propertyParameters->defrosting_duration = 30;
	propertyParameters->defrosting_drip_time = 5;
	propertyParameters->defrosting_mode = 0;
	propertyParameters->defrosting_temp_correction.T1 = 0;
	propertyParameters->defrosting_temp_correction.T2 = 0;
	propertyParameters->defrosting_temp_correction.T3 = 0;
	propertyParameters->defrosting_temp_correction.T4 = 0;
	propertyParameters->defrosting_temp_correction.T5 = 0;
	propertyParameters->defrosting_temp_correction.T6 = 0;
	propertyParameters->defrosting_temp_correction.T7 = 0;
	propertyParameters->defrosting_temp_correction.T8 = 0;
	propertyParameters->defrosting_temp_correction.T9 = 0;
	propertyParameters->defrosting_temp_correction.T10 = 0;
	
	//向dataflash中的第一页写入出厂数值
	flash_Write32(DATAFLASH_PAGE0, (int *)propertyParameters, sizeof(SYS_Property)/4);
}


/**
	* @brief  四元组内容恢复出厂设置
  * @note   None(暂时的用法)
	* @param  需要写入出厂数据的四元组结构体变量
  * @retval None
  */
void Q_factory_setting(Quadruple *dev_quadruple)
{
	dev_quadruple->checkout = 0x66;
	dev_quadruple->connect_mode = 4;                        //3:一型一密方式 4:一机一密方式                     
	
	strcpy(dev_quadruple->hash_value, "");
	strcpy(dev_quadruple->ProductKey, "a1FfnLrRtqT");
	strcpy(dev_quadruple->ProductSecret, "WCUmSD0unxRnV8KA");
	strcpy(dev_quadruple->DeviceName, "_866262040316028");
	strcpy(dev_quadruple->DeviceSecret, "BNYUuI9OqDc0hDNLKLWSZEBr2f2DIOJE");
}


/**
 * @description: 将属性参数结构体变量propertyParameters的值存入page0
 * @param {void} 
 * @return: 
 */
void pp2page0(void)
{
	if (0 == ccpm_status.pp_modified) return ;
	
	//本质是对flash读写函数的简单封装
	flash_Write32(DATAFLASH_PAGE0, (int *)&propertyParameters, sizeof(SYS_Property)/4);             //数据写入data flash
	flash_Read32(DATAFLASH_PAGE0, (int *)&propertyParameters, sizeof(SYS_Property)/4);              //从data flash中读取数据
	ccpm_status.pp_modified = 0;
}


/**
 * @description: 将四元组结构体变量dev_quadruple的值存入page1
 * @param {void} 
 * @return: 
 */
void dq2page1(void)
{
	//本质是对flash读写函数的简单封装
	flash_Write32(DATAFLASH_PAGE1, (int *)&dev_quadruple, sizeof(Quadruple)/4);
	flash_Read32(DATAFLASH_PAGE1, (int *)&dev_quadruple, sizeof(Quadruple)/4);
}
