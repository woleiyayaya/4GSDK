#ifndef __DATA_TO_STORED_H
#define __DATA_TO_STORED_H
#include "tool_funcs.h"

#define DATAFLASH_PAGE0   0x0001F000
#define DATAFLASH_PAGE1  (DATAFLASH_PAGE0 + 0x200)

typedef struct
{
	int checkout;                                                   //校验位
	int connect_mode;                                               //连云模式 0X01表示一型一密方式,0X02表示一机一密方式
  char hash_value[40];                                            //哈希值
	char ProductKey[16];
	char ProductSecret[20];
	char DeviceName[20];
	char DeviceSecret[40];
}Quadruple;                                                       //四元组结构体


typedef struct 
{	
	int checkout_1;                                                 //校验位1
	int boot_temp;                                                  //开机温度             A1 -100.0 ~ 999.0 ℃
	int shutDown_temp;                                           	  //停机温度             A2 -100.0 ~ 999.0 ℃
	int temp_upper_limit;                                           //实时温度最高告警值   A3 -100.0 ~ 999.0 ℃
	int temp_lower_limit;                                       	  //实时温度最低告警值   A4 -100.0 ~ 999.0 ℃
	int alarm_delay;                                                //高低温告警延时       A6 0 ~120 分钟
	MultiChannel temp_correction;                                   //制冷温度校正         A8 -10 ~ 10 ℃
	int humidity_upper_limit;                                       //实时湿度最高告警值    B2 0 ~ 99 %
	int humidity_lower_limit;                                       //实时湿度最低告警值    B3 0 ~ 99 %
	MultiChannel humidity_correction;                               //湿度校正             B5 -10 ~ 20 %
	int shutDown_protection;                                        //压缩机停机保护时间    E1 0 ~ 120 分钟
	int lamp_status;                                                //灯状态               F1 0 关 1 开
	int power_status;                                               //开关机状态           F2 0 关 1 开
	int defrosting_cycle;                                           //化霜周期             G2 0 ~ 24小时
	int defrosting_end_temp;                                        //化霜结束温度         G3 0 ~ 20℃
	int defrosting_duration;                                        //化霜持续时间         G4 0 ~ 999分钟
	int defrosting_drip_time;                                       //化霜滴水时间         G5 0 ~ 999分钟
	int defrosting_mode;                                            //化霜方式             G6 0 电化霜 1 热气化霜 2 停机化霜
	MultiChannel defrosting_temp_correction;                        //化霜温度探头校正      G8 -10 ~ 10℃
  int checkout_2;                                                 //校验位2
}SYS_Property;                                                    //属性参数结构体(各设置项，需要被存入flash的项目)

extern Quadruple dev_quadruple;                                   //设备四元组
extern SYS_Property propertyParameters;                           //系统属性参数

void flash_Read32(unsigned int addr, int *dest, unsigned char num);   //读取flash中的内容
void flash_Write32(unsigned int addr, int *sour, unsigned char num);  //向flash中写入数据
int dataFlash_init(void);                                             //初始化data flash
void pp2page0(void);                                                  //将属性参数结构体变量propertyParameters的值存入page0
void dq2page1(void);                                                  //将四元组结构体变量dev_quadruple的值存入page1
#endif // !__DATA_TO_STORED_H

