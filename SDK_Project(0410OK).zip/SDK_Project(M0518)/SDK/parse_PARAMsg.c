#include "parse_PARAMsg.h"
#include "tool_funcs.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "data_to_Stored.h"


//��ִ��Ϣ��������ж�����
#define RECEIPT_OVER      (my_strstr(uart_msg.uart_rx, uart_msg.cnt_rx, "+MSUB", 5))        //��ȡ��"+MSUB", ���յ��˻�ִ��Ϣ

/************ local variables ************/
static char paramsStr[128];                                                                 //������Բ����ַ���
static char messageID[30];                                                                  //��ŷ�����Ϣ��messageID
static char id[12];                                                                         //��ŷ�����Ϣ��id
static char rssi[10];                                                                       //���rssi(�����ź�ǿ��ָʾ)


/************ local function prototype ************/
void takeOut_params(const char *msg, int len, char *params);                                //ȡ���������ֵ��ַ���
void taskOut_messageId(const char *msg, int len, char *messageID, char *id);                //ȡ��������Ϣ�е�messageID
void single_ChannelMsg(void);                                                               //������ͨ��������Ϣ
void multi_ChannelMsg(void);                                                                //������ͨ��������Ϣ
void deal_serviceMsg(void);                                                                 //����������Ϣ
void deal_CSQMsg(void);                                                                     //�����ź�ǿ��ָʾ


/**
 * @description: ������4Gģ��ԽӵĴ��ڵ���Ϣ
 * @param {type} 
 * @return: 
 */
void parse_uartMsg(void)
{
	if (0 == ccpm_status.cc_succeed || 0 == ccpm_status.sub_succeed) return ;               //δ�ɹ����ӵ������ƻ�����ɻ��ⶩ��֮ǰ, ����Ҫ������Ϣ
	
	//����������Ϣ
	if (my_strstr(uart_msg.uart_rx, uart_msg.cnt_rx, "service", 7) && my_strstr(uart_msg.uart_rx, uart_msg.cnt_rx, "set", 3) && my_strstr(uart_msg.uart_rx, uart_msg.cnt_rx, "version", 7))
  {
		takeOut_params(uart_msg.uart_rx, uart_msg.cnt_rx, paramsStr);                         //ȡ���������ֵ��ַ���
		clean_uartMessage(&uart_msg);                                                         //��մ�����Ϣ����
		
		//������ͨ����������Ϣ
		if (my_strstr(paramsStr, strlen(paramsStr), "A8", 2) || my_strstr(paramsStr, strlen(paramsStr), "B5", 2) || my_strstr(paramsStr, strlen(paramsStr), "G8", 2))
    {
			multi_ChannelMsg();
    }
		//������ͨ����������Ϣ
		else
		{
			single_ChannelMsg();                                            
		}
		return ;
  }
	
	//����������Ϣ
	if (my_strstr(uart_msg.uart_rx, uart_msg.cnt_rx, "rrpc", 4) && my_strstr(uart_msg.uart_rx, uart_msg.cnt_rx, "request", 7))
  {
		deal_serviceMsg();
		return ;
  }
	
	//�����ź�ǿ�Ȳ�ѯ��Ϣ
	if (my_strstr(uart_msg.uart_rx, uart_msg.cnt_rx, "+CSQ", 3) && my_strstr(uart_msg.uart_rx, uart_msg.cnt_rx, "OK", 2))
  {
		deal_CSQMsg();
		return ;
  }
	
	//�������õ���Ϣ(ֱ��ɾ��)
	clean_uartMessage(&uart_msg);                                                          //ֱ�������Ϣ����
}


/**
 * @description: ������ͨ����Ϣ
 * @param {void} 
 * @return: 
 */
void single_ChannelMsg(void)
{
	unsigned char i;
	unsigned char j = 0;
	char dataStr[10];                                                                      //��������ַ���
	
	memset(dataStr, '\0', sizeof(dataStr));
	for(i = 5;i < strlen(paramsStr);i++)                                                   //��ȡ�����ַ���
  {
		if (':' == paramsStr[i - 1])
    {
			do { dataStr[j++] = paramsStr[i++]; } while (!('}' == paramsStr[i]));
      break;
    }
  }
	
	if (my_strstr(paramsStr, strlen(paramsStr), "A1", 2))                                  //A1 �����¶�
  {
		propertyParameters.boot_temp = (int)(atof(dataStr) * 10);                            //��ȡ�¶�ֵ
		
		//�ϴ�һ������ֵ A1
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A1':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (propertyParameters.boot_temp/10.0f));
  }
	else if (my_strstr(paramsStr, strlen(paramsStr), "A2", 2))                             //A2 ͣ���¶�
  {
		propertyParameters.shutDown_temp = (int)(atof(dataStr) * 10);

		//�ϴ�һ������ֵ A2
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A2':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (propertyParameters.shutDown_temp/10.0f));
  }
	else if (my_strstr(paramsStr, strlen(paramsStr), "A3", 2))                             //A3 ʵʱ�¶���߸澯ֵ
  {
		propertyParameters.temp_upper_limit = (int)(atof(dataStr) * 10);
		
		//�ϴ�һ������ֵ A3
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A3':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (propertyParameters.temp_upper_limit/10.0f));
	}
	else if (my_strstr(paramsStr, strlen(paramsStr), "A4", 2))                             //A4 ʵʱ�¶���͸澯ֵ
  {
		propertyParameters.temp_lower_limit = (int)(atof(dataStr) * 10);

		//�ϴ�һ������ֵ A4		
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A4':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (float)(propertyParameters.temp_lower_limit/10.0f));
	}
	else if (my_strstr(paramsStr, strlen(paramsStr), "A6", 2))                             //A6 �ߵ��¸澯��ʱ
  {
		propertyParameters.alarm_delay = (int)atoi(dataStr);

		//�ϴ�һ������ֵ	A6	
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A6':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.alarm_delay);
	}
	else if (my_strstr(paramsStr, strlen(paramsStr), "B2", 2))                             //B2 ʵʱʪ����߸澯ֵ
  {
		propertyParameters.humidity_upper_limit = (int)(atof(dataStr) * 10);
		
		//�ϴ�һ������ֵ		
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'B2':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.humidity_upper_limit/10);
	}
	else if (my_strstr(paramsStr, strlen(paramsStr), "B3", 2))                             //B3 ʵʱʪ����͸澯ֵ
  {
		propertyParameters.humidity_lower_limit = (int)(atof(dataStr) * 10);

		//�ϴ�һ������ֵ B3		
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'B3':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.humidity_lower_limit/10);
	}
	else if (my_strstr(paramsStr, strlen(paramsStr), "E1", 2))                             //E1 ѹ����ͣ������ʱ��
  {
		propertyParameters.shutDown_protection = atoi(dataStr);

		//�ϴ�һ������ֵ E1		
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'E1':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.shutDown_protection);
	}
	else if (my_strstr(paramsStr, strlen(paramsStr), "F1", 2))                             //F1 ��״̬
  {
		propertyParameters.lamp_status = atoi(dataStr);

		//�ϴ�һ������ֵ F1		
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'F1':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.lamp_status);
	}
	else if (my_strstr(paramsStr, strlen(paramsStr), "F2", 2))                             //F2 ���ػ�״̬
  {
		propertyParameters.power_status = atof(dataStr);
 
		//�ϴ�һ������ֵ F2		
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'F2':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.power_status);
	}
	else if (my_strstr(paramsStr, strlen(paramsStr), "G2", 2))                             //G2 ��˪����
  {
		propertyParameters.defrosting_cycle = atoi(dataStr);
		
		//�ϴ�һ������ֵ G2
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G2':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.defrosting_cycle);
	}
	else if (my_strstr(paramsStr, strlen(paramsStr), "G3", 2))                             //G3 ��˪�����¶�
  {
		propertyParameters.defrosting_end_temp = (int)(atof(dataStr) * 10);

		//�ϴ�һ������ֵ G3
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G3':%.1f},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, (propertyParameters.defrosting_end_temp/10.0f));
	}
	else if (my_strstr(paramsStr, strlen(paramsStr), "G4", 2))                             //G4 ��˪����ʱ��
  {
		propertyParameters.defrosting_duration = atoi(dataStr);
		
		//�ϴ�һ������ֵ G4
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G4':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.defrosting_duration);
	}
	else if (my_strstr(paramsStr, strlen(paramsStr), "G5", 2))                             //G5 ��˪��ˮʱ��
  {
		propertyParameters.defrosting_drip_time = atoi(dataStr);
  
		//�ϴ�һ������ֵ G5
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G5':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.defrosting_drip_time);
	}
	else if (my_strstr(paramsStr, strlen(paramsStr), "G6", 2))                             //G6 ��˪��ʽ
  {
		propertyParameters.defrosting_mode = atoi(dataStr);
  
		//�ϴ�һ������ֵ G6
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G6':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.defrosting_mode);
	}
	
	ccpm_status.waitting_receipt = 1;                                                      //�ȴ���Ϣ��ִ
	ccpm_status.pp_modified = 1;                                                           //�������޸�, ��Ҫ����data flash
}


/**
 * @description: ������ͨ��������Ϣ
 * @param {void} 
 * @return: 
 */
void multi_ChannelMsg(void)
{
	unsigned int i;
	unsigned int j;
	char T1[6];
	char T2[6];
	char T3[6];
	char T4[6];
	char T5[6];
	char T6[6];	
	char T7[6];
	char T8[6];
	char T9[6];	
	char T10[6];
	
	for(i = 6;i < strlen(paramsStr);i++)                                                   //��ȡ�����ַ���
  {
		j = 0;
		if ('T' == paramsStr[i - 4])                                        
    {
			if (':' == paramsStr[i])                                                           //T10������ǰ��, ��ֹ��T1����
      {
				i++;
				do {T10[j++] = paramsStr[i++];} while (',' != paramsStr[i]);
				T10[j] = '\0';
      }
			else if ('1' == paramsStr[i - 3])
      {
				do {T1[j++] = paramsStr[i++];} while (',' != paramsStr[i]);
				T1[j] = '\0';
      }
			else if ('2' == paramsStr[i - 3])
			{
				do {T2[j++] = paramsStr[i++];} while (!(',' == paramsStr[i] || '}' == paramsStr[i]));
				T2[j] = '\0';
			}
			else if ('3' == paramsStr[i - 3])
			{
				do {T3[j++] = paramsStr[i++];} while (!(',' == paramsStr[i] || '}' == paramsStr[i]));
				T3[j] = '\0';
			}
			else if ('4' == paramsStr[i - 3])
			{
				do {T4[j++] = paramsStr[i++];} while (!(',' == paramsStr[i] || '}' == paramsStr[i]));
				T4[j] = '\0';
			}
			else if ('5' == paramsStr[i - 3])
			{
				do {T5[j++] = paramsStr[i++];} while (!(',' == paramsStr[i] || '}' == paramsStr[i]));
				T5[j] = '\0';
			}
			else if ('6' == paramsStr[i - 3])
			{
				do {T6[j++] = paramsStr[i++];} while (!(',' == paramsStr[i] || '}' == paramsStr[i]));
				T6[j] = '\0';
			}
			else if ('7' == paramsStr[i - 3])
			{
				do {T7[j++] = paramsStr[i++];} while (!(',' == paramsStr[i] || '}' == paramsStr[i]));
				T7[j] = '\0';
			}
			else if ('8' == paramsStr[i - 3])
			{
				do {T8[j++] = paramsStr[i++];} while (!(',' == paramsStr[i] || '}' == paramsStr[i]));
				T8[j] = '\0';
			}
			else if ('9' == paramsStr[i - 3])
			{
				do {T9[j++] = paramsStr[i++];} while (!(',' == paramsStr[i] || '}' == paramsStr[i]));
				T9[j] = '\0';
			}
			else if ('1' == paramsStr[i - 3])
			{
				UART_Write(UART3, (uint8_t *)"\r\nlalalala\r\n", 12);
			}
    }
  }
	
	if (my_strstr(paramsStr, strlen(paramsStr), "A8", 2))
  {
		propertyParameters.temp_correction.T1 = atoi(T1);
		propertyParameters.temp_correction.T2 = atoi(T2);
		propertyParameters.temp_correction.T3 = atoi(T3);
		propertyParameters.temp_correction.T4 = atoi(T4);
		propertyParameters.temp_correction.T5 = atoi(T5);
		propertyParameters.temp_correction.T6 = atoi(T6);
		propertyParameters.temp_correction.T7 = atoi(T7);
		propertyParameters.temp_correction.T8 = atoi(T8);
		propertyParameters.temp_correction.T9 = atoi(T9);
		propertyParameters.temp_correction.T10 = atoi(T10);
		
		//�ϴ�һ������ֵ A8 int
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'A8':{'T1':%d,'T2':%d,'T3':%d,'T4':%d,'T5':%d,'T6':%d,'T7':%d,'T8':%d,'T9':%d,'T10':%d}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		propertyParameters.temp_correction.T1, propertyParameters.temp_correction.T2, propertyParameters.temp_correction.T3, \
		propertyParameters.temp_correction.T4, propertyParameters.temp_correction.T5, propertyParameters.temp_correction.T6, propertyParameters.temp_correction.T7, \
		propertyParameters.temp_correction.T8, propertyParameters.temp_correction.T9, propertyParameters.temp_correction.T10);
  }
	else if (my_strstr(paramsStr, strlen(paramsStr), "B5", 2))
  {
		propertyParameters.humidity_correction.T1 = atoi(T1);
		propertyParameters.humidity_correction.T2 = atoi(T2);
		propertyParameters.humidity_correction.T3 = atoi(T3);
		propertyParameters.humidity_correction.T4 = atoi(T4);
		propertyParameters.humidity_correction.T5 = atoi(T5);
		propertyParameters.humidity_correction.T6 = atoi(T6);
		propertyParameters.humidity_correction.T7 = atoi(T7);
		propertyParameters.humidity_correction.T8 = atoi(T8);
		propertyParameters.humidity_correction.T9 = atoi(T9);
		propertyParameters.humidity_correction.T10 = atoi(T10);
  
		//�ϴ�һ������ֵ B5 int
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'B5':{'T1':%d,'T2':%d,'T3':%d,'T4':%d,'T5':%d,'T6':%d,'T7':%d,'T8':%d,'T9':%d,'T10':%d}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		propertyParameters.humidity_correction.T1, propertyParameters.humidity_correction.T2, propertyParameters.humidity_correction.T3, \
		propertyParameters.humidity_correction.T4, propertyParameters.humidity_correction.T5, propertyParameters.humidity_correction.T6, propertyParameters.humidity_correction.T7, \
		propertyParameters.humidity_correction.T8, propertyParameters.humidity_correction.T9, propertyParameters.humidity_correction.T10);
	}
	else if (my_strstr(paramsStr, strlen(paramsStr), "G8", 2))
  {
		propertyParameters.defrosting_temp_correction.T1 = atoi(T1);
		propertyParameters.defrosting_temp_correction.T2 = atoi(T2);
		propertyParameters.defrosting_temp_correction.T3 = atoi(T3);
		propertyParameters.defrosting_temp_correction.T4 = atoi(T4);
		propertyParameters.defrosting_temp_correction.T5 = atoi(T5);
		propertyParameters.defrosting_temp_correction.T6 = atoi(T6);
		propertyParameters.defrosting_temp_correction.T7 = atoi(T7);
		propertyParameters.defrosting_temp_correction.T8 = atoi(T8);
		propertyParameters.defrosting_temp_correction.T9 = atoi(T9);
		propertyParameters.defrosting_temp_correction.T10 = atoi(T10);
  
		//�ϴ�һ������ֵ G8 int
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'G8':{'T1':%d,'T2':%d,'T3':%d,'T4':%d,'T5':%d,'T6':%d,'T7':%d,'T8':%d,'T9':%d,'T10':%d}},\
		'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, \
		propertyParameters.defrosting_temp_correction.T1, propertyParameters.defrosting_temp_correction.T2, propertyParameters.defrosting_temp_correction.T3, \
		propertyParameters.defrosting_temp_correction.T4, propertyParameters.defrosting_temp_correction.T5, propertyParameters.defrosting_temp_correction.T6, propertyParameters.defrosting_temp_correction.T7, \
		propertyParameters.defrosting_temp_correction.T8, propertyParameters.defrosting_temp_correction.T9, propertyParameters.defrosting_temp_correction.T10);
	}
	
	ccpm_status.waitting_receipt = 1;                                                      //�ȴ���Ϣ��ִ
	ccpm_status.pp_modified = 1;                                                           //�������޸�, ��Ҫ����data flash
}


/**
 * @description: ����������Ϣ
 * @param {void} 
 * @return: 
 */
void deal_serviceMsg(void)
{
	takeOut_params(uart_msg.uart_rx, uart_msg.cnt_rx, paramsStr);                         //ȡ���������ֵ��ַ���
	taskOut_messageId(uart_msg.uart_rx, uart_msg.cnt_rx, messageID, id);                  //ȡ��messageID��id
	
	if (my_strstr(uart_msg.uart_rx, uart_msg.cnt_rx, "lamp", 4))
	{
		if (my_strstr(paramsStr, strlen(paramsStr), "1", 1))
			propertyParameters.lamp_status = 1;
		else 
			propertyParameters.lamp_status = 0;
		
	  clean_uartMessage(&uart_msg);                                                       //��մ�����Ϣ����		
		//��ͬ�����õ�reponse
		printf("AT+MPUB=\"/sys/%s/%s/rrpc/response/%s\",0,0,\"{'id':'%s','code':200,'data':{'val':%d}}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, messageID, id, propertyParameters.lamp_status);
		
		//�������˵Ĳ����ϴ���������������ƽ̨
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'F1':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.lamp_status);
	}
	else if (my_strstr(uart_msg.uart_rx, uart_msg.cnt_rx, "power", 4))
	{
		if (my_strstr(paramsStr, strlen(paramsStr), "1", 1))
			propertyParameters.lamp_status = 1;
		else 
			propertyParameters.lamp_status = 0;
		
		clean_uartMessage(&uart_msg);                                                      //��մ�����Ϣ����
		//��ͬ�����õ�reponse
		printf("AT+MPUB=\"/sys/%s/%s/rrpc/response/%s\",0,0,\"{'id':'%s','code':200,'data':{'val':%d}}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, messageID, id, propertyParameters.power_status);
		
		//�������˵Ĳ����ϴ���������������ƽ̨
		printf("AT+MPUB=\"/sys/%s/%s/thing/event/property/post\",0,0,\
		\"{'params':{'F2':%d},'method':'thing.event.property.post'}\"\r\n", \
		dev_quadruple.ProductKey, dev_quadruple.DeviceName, propertyParameters.power_status);
	}

	ccpm_status.waitting_receipt = 1;                                                    //�ȴ���Ϣ��ִ
	ccpm_status.pp_modified = 1;                                                         //�������޸�, ��Ҫ����data flash
}


/**
 * @description: �����ź�ǿ��ָʾ
 * @param {void} 
 * @return: 
 */
void deal_CSQMsg(void)
{
	unsigned char i;
	unsigned char j;
	
	memset(rssi, '\0', sizeof(rssi));                                                   //ʹ��ǰ���rssi����
	for(i = 15;i < uart_msg.cnt_rx;i++)
	{
		if (' ' == uart_msg.uart_rx[i - 1] && 'Q' == uart_msg.uart_rx[i - 3] && 'C' == uart_msg.uart_rx[i - 5])
		{
			j = 0;
			do { rssi[j++] = uart_msg.uart_rx[i++]; } while (',' != uart_msg.uart_rx[i]);
			break;
		}
	}
	
	clean_uartMessage(&uart_msg);                                                       //�����Ϣ����
	ccpm_status.signalStrength = atoi(rssi);                                            //�ַ���ת����ֵ
}


/**
 * @description: ȡ���������ֵ��ַ���
 * @param {const char *} ��Ϣ�ַ���
 * @param {int}          ��Ϣ�ַ�������
 * @param {char *}       ���������ַ��� 
 * @return: 
 */
void takeOut_params(const char *msg, int len, char *params)
{
	unsigned int i;
	unsigned int j = 0;
	
	memset(paramsStr, '\0', sizeof(paramsStr));                                           //������Բ�������
	for(i = 70;i < len;i++)
  {
		if (':' == msg[i - 1] && 's' == msg[i - 3] && 'a' == msg[i - 5] && 'a' == msg[i - 7])
    {
			do{ params[j++] = msg[i++]; } while (!(',' == msg[i] && 'v' == msg[i + 2] && 'r' == msg[i + 4]));
			return ;
    }
  }
}


/**
 * @description: ȡ��������Ϣ�е�messageID
 * @param {type} 
 * @param {type} 
 * @param {type} 
 * @return: 
 */
void taskOut_messageId(const char *msg, int len, char *messageID, char *id)
{
	unsigned int i;
	unsigned int j = 0;
	
	memset(messageID, '\0', sizeof(*messageID));
	memset(id, '\0', sizeof(*id));
	for(i = 36;i < len;i++)
  {
		if ('/' == msg[i - 1] && 't' == msg[i - 2] && 'e' == msg[i - 4] && 'q' == msg[i - 6])                      //����messageID
    {
			do{ messageID[j++] = msg[i++]; } while ('"' != msg[i]);
    }                  
		else if (':' == msg[i - 2] && 'd' == msg[i - 4] && 'i' == msg[i - 5])                                      //����id
    {
			do{ id[j++] = msg[i++]; } while ('"' != msg[i]);
    }
  }
}


/**
 * @description: ������ִ��Ϣ(�ڴ����жϷ������е���)(�����ж��Ƿ�����)
 * @param {void} 
 * @return: 
 */
void deal_receiptMsg(void)
{
	//������ִ��Ϣ
	if (1 == ccpm_status.waitting_receipt && (RECEIPT_OVER))
	{
		UART_Write(UART3, (uint8_t *)uart_msg.uart_rx, uart_msg.cnt_rx);
		
		if (ccpm_status.wr_timeout) ccpm_status.wr_timeout = 0;                     //�յ���ִ��Ϣ, ��ִ��Ϣ��ʱ��־λ����
		clean_uartMessage(&uart_msg);                                               //���������Ϣ
		ccpm_status.waitting_receipt = 0;                                           //��ִ��Ϣ��־λ����
	}
}

