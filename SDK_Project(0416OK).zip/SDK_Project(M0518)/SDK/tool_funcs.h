#ifndef __TOOL_FUNCS_H
#define __TOOL_FUNCS_H
#include "userConfig.h"
#include "M0518.h"


/* 串口消息接收结构体 */
typedef struct 
{
    char uart_rx[MAXRXLENGTH];                      //消息内容
    int cnt_rx;                                     //消息长度
}UART_Message;                                      //串口消息结构体

/* SDK工作状态结构体 */
typedef struct 
{
	unsigned char ccpm_timeout;                       //连云或消息通信阶段超时
	unsigned char cc_succeed;                         //连云成功
	unsigned char sub_succeed;                        //订阅成功
	unsigned char bootUpload_succeed;                 //开机上传属性参数成功
	unsigned char waitting_receipt;                   //等待回执消息中
	unsigned char signalStrength;                     //4G模块信号强度
	unsigned char pp_modified;                        //属性参数被修改
	unsigned char alarmOrNot;                         //是否上传告警事件
}CC_PM_Status;                                      //SDK工作状态结构体

/* 多通道结构体类型 */
typedef struct 
{
	int T1;                                           //通达1
	int T2;                                           //通达2
	int T3;                                           //通达3
	int T4;                                           //通达4
	int T5;                                           //通达5
	int T6;                                           //通达6
	int T7;                                           //通达7
	int T8;                                           //通达8
	int T9;                                           //通达9
	int T10;                                          //通达10
}MultiChannel;                                      //多通道结构体类型

/* 实时数据结构体 */
typedef struct
{
	MultiChannel realTime_temp;                       //实时温度
  MultiChannel realTime_humidity;                   //实时湿度
	MultiChannel realTime_defrostTemp;                //化霜探头温度
	MultiChannel APhaseVoltage;                       //A相电压
	MultiChannel BPhaseVoltage;                       //B相电压
	MultiChannel CPhaseVoltage;                       //C相电压
	MultiChannel APhaseCurrent;                       //A相电流
	MultiChannel BPhaseCurrent;                       //B相电流
	MultiChannel CPhaseCurrent;                       //C相电流
}REALTIME_data;                                     //实时数据结构体



#define RSSI          ccpm_status.signalStrength       //存放接收信号强度指示
#define PP_MODIFIED   ccpm_status.pp_modified          //属性参数修改标志位(在属性参数修改完成后将此标志位置一)
#define ALARMORNOT    ccpm_status.alarmOrNot           //告警信息标志位(在填写了告警信息后将此标志位置一)

extern UART_Message uart_msg;                          //串口消息结构体变量
extern CC_PM_Status ccpm_status;                       //SDK工作状态结构体变量
extern REALTIME_data realTime_data;                    //实时数据结构体变量

void clean_uartMessage(UART_Message *uart_msg);                                                                //清空串口消息数组
unsigned char my_strstr(const char *str1, unsigned int str1_len, const char *str2, unsigned int str2_len);     //在给定字符串中查找给定子字符串
void my_memset(char *str, unsigned int len);                                                                  //清空给定数组的给定个数元素
void reset_4GModule(void);                                                                                     //复位4G模组
void clear_ccpm_status(void);                                                                                  //复位SDK状态(属性参数修改标志位除外)
#endif

