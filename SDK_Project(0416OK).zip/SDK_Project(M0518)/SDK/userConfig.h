#ifndef __USERCONFIG_H
#define __USERCONFIG_H


#define MAXRXLENGTH                       1024                      //串口消息数组最大长度
#define TIME_IN_EVERY_PROCEDURE           5                         //连云、消息解析过程中, 允许停留在每个步骤的秒数

#endif

