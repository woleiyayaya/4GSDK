#ifndef __CONNECT_TO_ALICLOUD_H
#define __CONNECT_TO_ALICLOUD_H

struct str_description
{
		char str_content[150];                                   //"download"之后的消息内容
    unsigned char str_len;                                   //消息长度
};

void connect_to_AliCloud(void);                              //连接到阿里云
void reconnect_AliCloud_1(void);                             //连云阶段重连阿里云
void reconnect_AliCloud_2(void);                             //中途掉线时重连阿里云
#endif

