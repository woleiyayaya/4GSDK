#include "tool_funcs.h"

/************   global variable   ************/
UART_Message uart_msg = {"", 0};                                   //串口消息结构体变量
CC_PM_Status ccpm_status = {0, 0, 0, 0, 0, 0, 0, 0};               //SDK工作状态结构体变量   
REALTIME_data realTime_data = {10};                                //实时数据结构体变量


/**
 * @description: 清空串口消息数组
 * @param {UART_Message *} 
 * @return: none
 */
void clean_uartMessage(UART_Message *uart_msg)
{
	int i;

	for (i = 0; i < uart_msg->cnt_rx; i++)
	{
		uart_msg->uart_rx[i] = ' ';
	}
	uart_msg->cnt_rx = 0;
}


/**
  * @brief  在给定父字符串中查找给定子字符串
  * @note   None
  * @param  父字符串
  * @param  父字符串长度
  * @param  子符串
  * @param  子字符串长度
  * @retval 1:找到给定字符串 0:没有找到给定字符串
  */
unsigned char my_strstr(const char *str1, unsigned int str1_len, const char *str2, unsigned int str2_len)
{
	unsigned int i,j;
	
	if(str1_len <= str2_len) return 0;                                     //排除父字符串过短的情形
	for(i = 0;i < str1_len - str2_len + 1;i++)
	{
		if (str2[0] == str1[i])
		{
			for(j = 1;j < str2_len;j++)
			{
				if(str1[i + j] == str2[j]) ;                                    //当前字符相等则继续
				else break;                                                     //当前字符不等则跳出循环
			}
		}
		if(str2_len == j)
			return 1;                                                         //完美匹配
	}
	return 0;                                                             //没有匹配的内容
}


/**
 * @description: 清空给定数组的给定个数元素
 * @param {char *}将要清空的数组
 * @param {int *}数组元素个数 
 * @return: None
 */
void my_memset(char *str, unsigned int len)
{
	unsigned int i;
	
	for(i = 0;i < (len);i++)
	{
		str[i] = '\0';
	}
	len = 0;
}


/**
  * @brief  复位4G模组
  * @note   None
  * @retval None
  */
void reset_4GModule(void)
{
	GPIO_SetMode(PA, BIT14, GPIO_PMD_OUTPUT);
	PA14 = 1;                                     //相当于按下reset
	PA14 = 0;                                     //相当于松开reset
}


/**
 * @description: 复位SDK状态(属性参数修改标志位除外)
 * @param {void} 
 * @return: 
 */
void clear_ccpm_status(void)
{
	ccpm_status.ccpm_timeout = 0;
	ccpm_status.cc_succeed = 0;
	ccpm_status.sub_succeed = 0;
	ccpm_status.bootUpload_succeed = 0;
	ccpm_status.waitting_receipt = 0;
	ccpm_status.signalStrength = 0;
}

