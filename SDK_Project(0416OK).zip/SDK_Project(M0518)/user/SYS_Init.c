#include <stdlib.h>
#include "M0518.h"
#include "SYS_Init.h"


/**
 * @brief This function updates clock registers to fulfil the configuration
 * @param None
 * @return None
 */
void SYS_Clock_Init(void)
{
/*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/
    //CLK->PWRCON = (CLK->PWRCON & ~(0x0000000Dul)) | 0x0000001Cul;
    //CLK->PLLCON = (CLK->PLLCON & ~(0x000FFFFFul)) | 0x0005C22Eul;
    //CLK->CLKDIV = (CLK->CLKDIV & ~(0x00FF0F0Ful)) | 0x00000000ul;
    //CLK->CLKSEL0 = (CLK->CLKSEL0 & ~(0x0000003Ful)) | 0x0000003Ful;
    //CLK->CLKSEL1 = (CLK->CLKSEL1 & ~(0x0377771Ful)) | 0xFFFFFFFFul;
    //CLK->CLKSEL2 = (CLK->CLKSEL2 & ~(0x0003000Cul)) | 0x000200FFul;
    //CLK->CLKSEL3 = (CLK->CLKSEL3 & ~(0x000F0000ul)) | 0x000F003Ful;
    //CLK->AHBCLK = (CLK->AHBCLK & ~(0x00000004ul)) | 0x00000001ul;
    //CLK->APBCLK = (CLK->APBCLK & ~(0x1007137Dul)) | 0x1004000Dul;
    //CLK->APBCLK1 = (CLK->APBCLK1 & ~(0x000F0700ul)) | 0x00000100ul;
    //CLK->FRQDIV = (CLK->FRQDIV & ~(0x0000003Ful)) | 0x00000000ul;
    //SysTick->CTRL = (SysTick->CTRL & ~(0x00000005ul)) | 0x00000000ul;

    /* Unlock protected registers */
    SYS_UnlockReg();

    /* Enable clock source */
    CLK_EnableXtalRC(CLK_PWRCON_OSC10K_EN_Msk|CLK_PWRCON_OSC22M_EN_Msk);

    /* Waiting for clock source ready */
    CLK_WaitClockReady(CLK_CLKSTATUS_OSC10K_STB_Msk|CLK_CLKSTATUS_OSC22M_STB_Msk);

    /* If the defines do not exist in your project, please refer to the related clk.h in the Header folder appended to the tool package. */
    /* Set HCLK clock */
    CLK_SetHCLK(CLK_CLKSEL0_HCLK_S_HIRC, CLK_CLKDIV_HCLK(1));

    /* Enable IP clock */
    CLK_EnableModuleClock(ADC_MODULE);
    CLK_EnableModuleClock(TMR0_MODULE);
    CLK_EnableModuleClock(TMR1_MODULE);
    CLK_EnableModuleClock(UART2_MODULE);
    CLK_EnableModuleClock(UART3_MODULE);
    CLK_EnableModuleClock(WDT_MODULE);
    CLK_EnableModuleClock(WWDT_MODULE);

    /* Set IP clock */
    CLK_SetModuleClock(ADC_MODULE, CLK_CLKSEL1_ADC_S_HIRC, CLK_CLKDIV_ADC(1));
    CLK_SetModuleClock(TMR0_MODULE, CLK_CLKSEL1_TMR0_S_HIRC, MODULE_NoMsk);
    CLK_SetModuleClock(TMR1_MODULE, CLK_CLKSEL1_TMR1_S_HIRC, MODULE_NoMsk);
    CLK_SetModuleClock(UART2_MODULE, CLK_CLKSEL1_UART_S_HIRC, CLK_CLKDIV_UART(1));
    CLK_SetModuleClock(UART3_MODULE, CLK_CLKSEL1_UART_S_HIRC, CLK_CLKDIV_UART(1));
    CLK_SetModuleClock(WDT_MODULE, CLK_CLKSEL1_WDT_S_LIRC, MODULE_NoMsk);
    CLK_SetModuleClock(WWDT_MODULE, CLK_CLKSEL2_WWDT_S_HCLK_DIV2048, MODULE_NoMsk);

    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate SystemCoreClock. */
    SystemCoreClockUpdate();

    /* Lock protected registers */
    SYS_LockReg();

    return;
}


/**
 * @brief This function provides the configued MFP registers
 * @param None
 * @return None
 */
void SYS_Pin_Init(void)
{
    //SYS->ALT_MFP = 0x00000000;
    //SYS->ALT_MFP2 = 0x00000000;
    //SYS->ALT_MFP3 = 0x00000000;
    //SYS->ALT_MFP4 = 0x00000030;
    //SYS->GPA_MFP = 0x000000F0;
    //SYS->GPB_MFP = 0x00000000;
    //SYS->GPC_MFP = 0x00000000;
    //SYS->GPD_MFP = 0x0000C000;
    //SYS->GPF_MFP = 0x000000C0;

    //If the defines do not exist in your project, please refer to the corresponding sys.h in the Header folder appended to the tool package.
    SYS->ALT_MFP = 0x00000000;
    SYS->ALT_MFP2 = 0x00000000;
    SYS->ALT_MFP3 = 0x00000000;
    SYS->ALT_MFP4 = SYS_ALT_MFP4_PA6_UART3_TXD | SYS_ALT_MFP4_PA5_UART3_RXD;
    SYS->GPA_MFP = SYS_GPA_MFP_PA7_ADC7 | SYS_GPA_MFP_PA6_UART3_TXD | SYS_GPA_MFP_PA5_UART3_RXD | SYS_GPA_MFP_PA4_ADC4;
    SYS->GPB_MFP = 0x00000000;
    SYS->GPC_MFP = 0x00000000;
    SYS->GPD_MFP = SYS_GPD_MFP_PD15_UART2_TXD | SYS_GPD_MFP_PD14_UART2_RXD;
    SYS->GPF_MFP = SYS_GPF_MFP_PF7_ICE_DAT | SYS_GPF_MFP_PF6_ICE_CLK;

    return;
}


/*---------------------------------------------------------------------------------------------------------*/
/* UART0 Init                                                                                */
/*---------------------------------------------------------------------------------------------------------*/
//void UART0_Init(void)
//{
//    /* Reset UART0 module */
//    SYS_ResetModule(UART0_RST);

//		/* Configure UART0 and set UART0 Baudrate *///����0 ������:115200 ���ݳ���:8bit ��żУ��λ:NONE ֹͣλ:1bit
//    UART_Open(UART0, 115200);
//}

/*---------------------------------------------------------------------------------------------------------*/
/* UART1 Init                                                                                */
/*---------------------------------------------------------------------------------------------------------*/
//void UART1_Init(void)
//{
//    /* Reset UART1 module */
//    SYS_ResetModule(UART1_RST);

//		/* Configure UART1 and set UART1 Baudrate *///����1 ������:115200 ���ݳ���:8bit ��żУ��λ:NONE ֹͣλ:1bit
//    UART_Open(UART1, 115200);
//	
//		//ʹ�ܴ���1 �ж� �ж������� Rx ready interrupt
//		UART_EnableInt(UART1, UART_IER_RDA_IEN_Msk);
//	
//		/* Enable UART1 NVIC */
//		NVIC_EnableIRQ(UART1_IRQn);
//}

/*---------------------------------------------------------------------------------------------------------*/
/* UART2 Init                                                                                */
/*---------------------------------------------------------------------------------------------------------*/
void UART2_Init(void)
{
    /* Reset UART0 module */
    SYS_ResetModule(UART2_RST);

		/* Configure UART2 and set UART2 Baudrate *///����2 ������:115200 ���ݳ���:8bit ��żУ��λ:NONE ֹͣλ:1bit
    UART_Open(UART2, 115200);
		
		//ʹ�ܴ���2 �ж� �ж������� Rx ready interrupt -- Rx time-out interrupt
		UART_EnableInt(UART2, (UART_IER_RDA_IEN_Msk | UART_IER_TOUT_IEN_Msk));
	
		/* Enable UART2 NVIC */
		NVIC_EnableIRQ(UART02_IRQn);  
}

/*---------------------------------------------------------------------------------------------------------*/
/* UART3 Init                                                                                */
/*---------------------------------------------------------------------------------------------------------*/
void UART3_Init(void)
{
    /* Reset UART3 module */
    SYS_ResetModule(UART3_RST);

		/* Configure UART3 and set UART3 Baudrate *///����3 ������:115200 ���ݳ���:8bit ��żУ��λ:NONE ֹͣλ:1bit
    UART_Open(UART3, 115200);
		
		//ʹ�ܴ���3 �ж� �ж������� Rx ready interrupt
		UART_EnableInt(UART3, UART_IER_RDA_IEN_Msk);
	
		/* Enable uart3 NVIC */
		NVIC_EnableIRQ(UART3_IRQn);
}

/*---------------------------------------------------------------------------------------------------------*/
/* UART4 Init                                                                                */
/*---------------------------------------------------------------------------------------------------------*/
//void UART4_Init(void)
//{
//    /* Reset UART4 module */
//    SYS_ResetModule(UART4_RST);

//		/* Configure UART4 and set UART4 Baudrate *///����4 ������:115200 ���ݳ���:8bit ��żУ��λ:NONE ֹͣλ:1bit
//    UART_Open(UART4, 115200);
//		
//		//ʹ�ܴ���4 �ж� �ж������� Rx ready interrupt -- Rx time-out interrupt
//		UART_EnableInt(UART4, UART_IER_RDA_IEN_Msk );
//	
//		/* Enable uart4 NVIC */
//		NVIC_EnableIRQ(UART4_IRQn);
//}

/*---------------------------------------------------------------------------------------------------------*/
/* UART5 Init                                                                                */
/*---------------------------------------------------------------------------------------------------------*/
//void UART5_Init(void)
//{
//    /* Reset UART5 module */
//    SYS_ResetModule(UART5_RST);

//		/* Configure UART5 and set UART5 Baudrate *///����5 ������:115200 ���ݳ���:8bit ��żУ��λ:NONE ֹͣλ:1bit
//    UART_Open(UART5, 115200);
//		
//		//ʹ�ܴ���5 �ж� �ж������� Rx ready interrupt -- Rx time-out interrupt
//		UART_EnableInt(UART5, UART_IER_RDA_IEN_Msk);
//	
//		/* Enable uart5 NVIC */
//		NVIC_EnableIRQ(UART5_IRQn);
//}

/*---------------------------------------------------------------------------------------------------------*/
/* ADC Init                                                                           */
/*---------------------------------------------------------------------------------------------------------*/
void ADC_Init(void)
{
	 /* Set the ADC operation mode as single-cycle, input mode as single-end and enable the analog input channel 0 and 1 */
   ADC_Open(ADC, ADC_ADCR_DIFFEN_SINGLE_END, ADC_ADCR_ADMD_SINGLE_CYCLE, 0X3);
   
	 /* Power on ADC module */
   ADC_POWER_ON(ADC);
	
	 /* ʹ��ADC�ж�,ת����ɽ������ж� */
	 ADC_EnableInt(ADC, ADC_ADF_INT);
}

/*---------------------------------------------------------------------------------------------------------*/
/*  Timer Init                                                                                */
/*---------------------------------------------------------------------------------------------------------*/
void timer_Init(void)
{
	 /* Open Timer0 in periodic mode, enable interrupt and 1 interrupt tick per second */
	//���ڼ�ʱģʽ,ʹ�ܶ�ʱ���ж�
   TIMER_Open(TIMER0, TIMER_PERIODIC_MODE, 1);
   TIMER_EnableInt(TIMER0);

   /* Open Timer1 in periodic mode, enable interrupt and 1 interrupt ticks per second */
   TIMER_Open(TIMER1, TIMER_PERIODIC_MODE, 1);
   TIMER_EnableInt(TIMER1);
	
	/* Enable Timer0, Timer1 NVIC */
	//����NVIC
   NVIC_EnableIRQ(TMR0_IRQn);
   NVIC_EnableIRQ(TMR1_IRQn);
	
	/* Start Timer0, Timer1 counting */
	//���ö�ʱ����ʱ
   TIMER_Start(TIMER0);
   TIMER_Start(TIMER1);
}


//���ø��жϵ����ȼ�
void set_priority(void)
{
	//NVIC_SetPriority();
}

